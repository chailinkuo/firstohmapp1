package com.example.firstohm_produce_kotlin

import android.content.Intent
import android.os.Bundle
import android.os.StrictMode
import android.provider.AlarmClock.EXTRA_MESSAGE
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import co.ubunifu.kotlinhttpsample.Lib.WebapiClient
import com.google.zxing.integration.android.IntentIntegrator
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.custom_layout_main_button.*
import kotlinx.android.synthetic.main.custom_layout_quant_input.*
import kotlinx.android.synthetic.main.custom_layout_quant_input.view.*
import org.json.JSONException
import org.json.JSONObject
import java.util.*
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        this.supportActionBar?.hide()  //hide title bar
        ip="http://172.168.1.33:1111/"
        val policy = StrictMode.ThreadPolicy.Builder()
                .permitAll().build()
        StrictMode.setThreadPolicy(policy)
        val rootView = window.decorView.rootView
        val UI_Helper = UI_Helper(rootView)
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        btn_setting.setOnClickListener {
            startActivity(Intent(this@MainActivity, setting::class.java))
        }
        test_button.setOnClickListener{
            login()
        }
        bnt_selectMachins.setOnClickListener{
            startActivity(Intent(this@MainActivity, select_Machins::class.java))
        }
        sance_btn.setOnClickListener{
            val scanIntegrator = IntentIntegrator(this)
            scanIntegrator.initiateScan()
        }
        test_flow.setOnClickListener{
            flowbar="17720-1-2048071-0-%25"
            userBar="B_005"
            dept="花蓮切割"
            val rootView = window.decorView.rootView
            val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
            val co = CustomLayoutSubflowInfo(this@MainActivity,null)
            val data=ui_Helper.get_subflowInfo(flowbar, userBar, dept, rootView, this@MainActivity)
            co.inputViewItems(data,rootView)
        }
        if(!flowbar.equals("")){
            test_flow.performClick();
            login()

        }
        // Get the Intent that started this activity and extract the string
        val message = intent.getStringExtra(EXTRA_MESSAGE)
        val mid = findViewById<TextView>(R.id.mid_text).apply {
            text = message
        }
    }
    private fun login() {
        val json = JSONObject()
        var webapiClient = WebapiClient()
        val rootView = window.decorView.rootView
        val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
        var jsonString:String?=webapiClient.requestPOST(ip + "firstohmWebApi/PrdMgn/Login?userBar=*C_004&Dept=%E8%8A%B1%E8%93%AE%E5%88%87%E5%89%B2&facroryNo=1", json)
        val jsonStr = JSONObject(jsonString)
        ui_Helper.login(jsonStr, rootView)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            // If QRCode has no data.
            if (result.contents == null) {
                //Toast.makeText(this, getString(R.string.result_not_found), Toast.LENGTH_LONG).show()
            } else {
                // If QRCode contains data.
                try {
                    // Converting the data to json format
                    val obj = result.getContents()
                    if (obj.indexOf("*") >= -1) {
                        userBar = obj
                    }
                    if (obj.indexOf("%") >= -1) {
                        flowbar = obj
                    }
                } catch (e: JSONException) {
                    e.printStackTrace()
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }

    companion object{
        var ip: String = String()
        var dept: String = String()
        var userBar: String = String()
        var flowbar: String = String()
        var midlist = ArrayList<String>()
    }
}