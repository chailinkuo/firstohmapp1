package com.example.firstohm_produce_kotlin

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.android.synthetic.main.custom_layout_info.view.*
import org.json.JSONObject

class CustomLayoutSubflowInfo(
        context: Context,
        attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {
    init {
        inflate(context, R.layout.custom_layout_info, this)
        val customAttributesStyle = context.obtainStyledAttributes(
                attrs,
                R.styleable.custom_layout_info,
                0,
                0
        )
        val textView_mfo_id = findViewById<TextView>(R.id.textView_mfo_id_value)
    }
    //write layout
    public fun inputViewItems(jsonObj: JSONObject, view: View){
        view.textView_mfo_id_value.setText(jsonObj.getString("mfo_id"))
        var BATCH_NO=jsonObj.getString("BATCH_NO")
        var BATSEQ: Int = Integer.valueOf(jsonObj.getString("BATSEQ"))
        BATSEQ = BATSEQ + 1
        view.BATCH_NO_text_value.setText("  $BATSEQ / $BATCH_NO")
        view.BATCH_QTY_text_value.setText(jsonObj.getString("BATCH_QTY"))
        view.RTYPE_text_value.setText(jsonObj.getString("RTYPE"))
        view.TOL_text_value.setText("  ±" + jsonObj.getString("TOL")+ "%")
    }
}