package com.example.firstohm_produce_kotlin

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.custom_layout_main_button.view.*

class custom_layout_main_button (
        context: Context,
        attrs: AttributeSet
) : LinearLayout(context, attrs) {
    init {
        inflate(context, R.layout.custom_layout_main_button, this)
        val customAttributesStyle = context.obtainStyledAttributes(
                attrs,
                R.styleable.custom_layout_main_button,
                0,
                0
        )
        val UI_Helper = UI_Helper(rootView)
        flow_start_btn.setOnClickListener {
            val inflater = LayoutInflater.from(context)
            val v: View = inflater.inflate(R.layout.dialog_start_flow, null)
            UI_Helper.show_dlg(context, v)
        }
    }
}