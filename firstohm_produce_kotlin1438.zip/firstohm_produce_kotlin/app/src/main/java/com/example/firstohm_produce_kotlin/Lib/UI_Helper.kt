package co.ubunifu.kotlinhttpsample.Lib

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import com.example.firstohm_produce_kotlin.*
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.custom_layout_info.view.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*


class UI_Helper(view: View){

    public fun mesage(rore: String, context: Context) {
        val builder =
            androidx.appcompat.app.AlertDialog.Builder(context)
        builder.setMessage(rore)
        builder.setCancelable(false)
        builder.setPositiveButton(
                "確認"
        ) { dialog, id -> }
        builder.show()
    }


    public fun retriveFromJsonStrn(jsonString: String, retriveItem: String? = null): Any? {
        var jsonObj = JSONObject(JSONObject(jsonString).getString("Data"))
        if(retriveItem==null)
            return jsonObj
        else
            return jsonObj.opt(retriveItem)
    }
    public fun jsonStrToObject(jsonString: String, elementName: String? = null): JSONObject? {
        return JSONObject(JSONObject(jsonString).getString(elementName ?: "Data"))
    }
    public fun get_subflowInfo(flow_bar: String,dept:String ,user_bar:String,view: View,context:Context): JSONObject {

        val inflater = LayoutInflater.from(context)
        val v: View = inflater.inflate(R.layout.custom_layout_info, null)
        var webapiClient = WebapiClient()
        var url=MainActivity.ip+"firstohmWebApi/PrdMgn/ScanOperate?" +
                "command=0&UID=$user_bar&flowBar="+flow_bar+"&DEPT="+dept
        var jsonString:String?=webapiClient.requestPOST(
                "$url", JSONObject())
        val jsonStr = JSONObject(jsonString)
        val rtnData =  JSONObject(jsonStr.getString("Data"))
        val mfo_id = rtnData?.getString("mfo_id")
        return rtnData
    }

    public fun login(jsonStr: JSONObject, view: View){
        try {
            val rtnData =  JSONArray(jsonStr.getString("Data"))
            val jsonStrD = JSONObject(rtnData[0]?.toString())
            val Data_mid = jsonStrD?.getString("Machins")
            val DEPT = jsonStrD?.getString("DEPT")

            val EMPNAME = jsonStrD?.getString("EMPNAME")
            val array = JSONArray(Data_mid)
            val midlist = ArrayList<String>()
            for (j in 0 until array.length()) {
                val Jasonobject: String = array.getString(j) //O
                val array2 = JSONArray(Jasonobject) //o
                for (k in 0 until array2.length()) {
                    val ob2 = array2.getJSONObject(k)
                    val mid = ob2.getString("mid")
                    var attr2 = ob2.getString("attr2")
                    val status = ob2.getString("status")
                    //System.out.println("status==>"+mid+"01120"+status);
                    if (mid == "null") {
                        midlist.add("null")
                    } else {
                        //midlist.add(attr2 +"\n"+mid+"status"+status);
                        attr2 = attr2.replace("\\\\".toRegex(), "")
                        attr2 = attr2.replace("n".toRegex(), "  ")
                        midlist.add(attr2 + "  " + mid + "status" + status)
                    }
                }
                midlist.add("new")
            }
            MainActivity.midlist=midlist

            val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
            val today = sdf.format(Date())
            view.info_textView.setText("部門:$DEPT\t\t\t員工:$EMPNAME\t\t\t登入時間:$today")

        }catch (ex: Exception){
            Log.d("1", ex.message)
        }
    }

    //Todo obj to json
    //objRoJstr
    //Todo 還要加 Optional default value
    public fun set_spinner_data(targetSpiner: Spinner, context: Context, itemsList: JSONArray, defaulyVal: String?) {
        val list = Array(itemsList.length()) {
            itemsList.getString(it)
        }
        val arrayAdapter = ArrayAdapter(
                context,
                android.R.layout.simple_spinner_dropdown_item,
                list
        )
        targetSpiner.adapter = arrayAdapter
        if(defaulyVal!=null) {
            //Todo 设定预设值
            targetSpiner.setSelection((
                    targetSpiner.getAdapter() as ArrayAdapter<String?>).getPosition(defaulyVal))

        }
    }
    //---------------------------------------------------------------------------------

}

