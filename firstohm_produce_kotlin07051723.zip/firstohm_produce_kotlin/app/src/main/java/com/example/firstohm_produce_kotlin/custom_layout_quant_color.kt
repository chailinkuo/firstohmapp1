package com.example.firstohm_produce_kotlin


import android.content.Context
import android.util.AttributeSet
import android.widget.LinearLayout
class custom_layout_quant_color (
        context: Context,
        attrs: AttributeSet
) : LinearLayout(context, attrs) {
    init {
        inflate(context, R.layout.custom_layout_quant_color, this)
        val customAttributesStyle = context.obtainStyledAttributes(
                attrs,
                R.styleable.custom_layout_quant_color,
                0,
                0
        )
    }
}