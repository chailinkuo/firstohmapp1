package com.example.firstohm_produce_kotlin

import android.R
import android.app.AlertDialog
import android.content.DialogInterface
import android.util.TypedValue
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONObject
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import javax.net.ssl.HttpsURLConnection
import android.content.Context as Context1


class UI_Helper(view: View){
    val POST : String = "POST"
    fun requestPOST(r_url: String?, postDataParams: JSONObject): String? {
        val url = URL(r_url)
        val conn: HttpURLConnection = url.openConnection() as HttpURLConnection
        conn.readTimeout = 3000
        conn.connectTimeout = 3000
        conn.requestMethod = POST
        conn.doInput = true
        conn.doOutput = true
        val os: OutputStream = conn.outputStream
        val writer = BufferedWriter(OutputStreamWriter(os, "UTF-8"))
        writer.write(encodeParams(postDataParams))
        writer.flush()
        writer.close()
        os.close()
        val responseCode: Int = conn.responseCode // To Check for 200
        if (responseCode == HttpsURLConnection.HTTP_OK) {
            val `in` = BufferedReader(InputStreamReader(conn.inputStream))
            val sb = StringBuffer("")
            var line: String? = ""
            while (`in`.readLine().also { line = it } != null) {
                sb.append(line)
                break
            }
            `in`.close()
            return sb.toString()
        }
        return null
    }
    private fun encodeParams(params: JSONObject): String? {
        val result = StringBuilder()
        var first = true
        val itr = params.keys()
        while (itr.hasNext()) {
            val key = itr.next()
            val value = params[key]
            if (first) first = false else result.append("&")
            result.append(URLEncoder.encode(key, "UTF-8"))
            result.append("=")
            result.append(URLEncoder.encode(value.toString(), "UTF-8"))
        }
        return result.toString()
    }
    fun mesage(rore: String, context: Context1) {
        val builder =
                androidx.appcompat.app.AlertDialog.Builder(context)
        builder.setMessage(rore)
        builder.setCancelable(false)
        builder.setPositiveButton(
                "確認"
        ) { dialog, id -> }
        builder.show()
    }
    fun show_dlg(context: Context1,view:View){
        val dialog: AlertDialog.Builder = AlertDialog.Builder(context)
        val title = TextView(context)
        title.text = "開始"
        title.gravity = Gravity.CENTER
        title.textSize = 24f
        dialog.setCustomTitle(title)
        dialog.setView(view)
        dialog.setPositiveButton("送出", DialogInterface.OnClickListener {
            dialog, which ->


        })
        dialog.setNeutralButton("取消", DialogInterface.OnClickListener { dialog, which ->
            //mothing
        })
        val dlg: AlertDialog = dialog.show()
        val params: WindowManager.LayoutParams = dlg.window!!.getAttributes()
        params.width = 1200
        params.height = 700
        dlg.getButton(AlertDialog.BUTTON_POSITIVE).setTextSize(TypedValue.COMPLEX_UNIT_SP, 25.0f)
        dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setTextSize(TypedValue.COMPLEX_UNIT_SP, 25.0f)
        dlg.getWindow()!!.setAttributes(params)
    }
}