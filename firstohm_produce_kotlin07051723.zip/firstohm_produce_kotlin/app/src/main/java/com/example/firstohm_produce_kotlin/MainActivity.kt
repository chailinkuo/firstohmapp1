package com.example.firstohm_produce_kotlin

import android.content.Intent
import android.os.Bundle
import android.os.StrictMode
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import co.ubunifu.kotlinhttpsample.Lib.WebapiClient
import com.google.gson.Gson

import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.custom_layout_main_button.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.*


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        this.supportActionBar?.hide()  //hide title bar
        ip="http://172.168.1.33:1111/"
        val policy = StrictMode.ThreadPolicy.Builder()
                .permitAll().build()
        StrictMode.setThreadPolicy(policy)
        val rootView = window.decorView.rootView
        val UI_Helper = UI_Helper(rootView)
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        btn_setting.setOnClickListener {
            startActivity(Intent(this@MainActivity, setting::class.java))
        }
        flow_start_btn.setOnClickListener {
            val inflater = LayoutInflater.from(this@MainActivity)
            val v: View = inflater.inflate(R.layout.dialog_start_flow, null)
            UI_Helper.show_dlg(this@MainActivity, v)
        }
        test_button.setOnClickListener{
            login()
        }
    }

    private fun login() {
        val json = JSONObject()
        var webapiClient = WebapiClient()
        val rootView = window.decorView.rootView
        val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
        var jsonString:String?=webapiClient.requestPOST(ip + "firstohmWebApi/PrdMgn/Login?userBar=*C_004&Dept=%E8%8A%B1%E8%93%AE%E5%88%87%E5%89%B2&facroryNo=1", json)
        val jsonStr = JSONObject(jsonString)
        ui_Helper.login(jsonStr,rootView)
    }

    companion object{
        var ip: String = String()
        var dept: String = String()
    }
}