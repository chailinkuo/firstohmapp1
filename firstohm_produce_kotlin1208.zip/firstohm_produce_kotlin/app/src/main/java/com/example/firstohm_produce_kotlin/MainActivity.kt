package com.example.firstohm_produce_kotlin

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Bundle
import android.os.StrictMode
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import co.ubunifu.kotlinhttpsample.Lib.*
import com.google.zxing.integration.android.IntentIntegrator
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.custom_layout_info.*
import kotlinx.android.synthetic.main.custom_layout_info.view.*
import kotlinx.android.synthetic.main.custom_layout_main_button.*
import kotlinx.android.synthetic.main.custom_layout_main_button.view.*
import kotlinx.android.synthetic.main.custom_layout_quant_color.*
import kotlinx.android.synthetic.main.custom_layout_quant_color.view.*
import kotlinx.android.synthetic.main.custom_layout_quant_input.*
import kotlinx.android.synthetic.main.custom_layout_quant_input.view.*
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.*
import java.util.regex.Matcher
import java.util.regex.Pattern


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        this.supportActionBar?.hide()  //hide title bar
        if (Build.VERSION.SDK_INT > 9) {
            val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
            StrictMode.setThreadPolicy(policy)
        }
        MainActivity.context = getApplicationContext();
        val cpuInfo = readCpuInfo()
        if ((cpuInfo.contains("Intel") || cpuInfo.contains("amd"))) {
            local_test_layout.visibility= View.VISIBLE
        }
        test_button.setOnClickListener{
            if ((cpuInfo.contains("Intel") || cpuInfo.contains("amd"))) {
                local_test_layout.visibility= View.VISIBLE
                userBar="C_004"
            }
            login()
        }
        test_flow.setOnClickListener{
            if ((cpuInfo.contains("Intel") || cpuInfo.contains("amd"))) {
                local_test_layout.visibility= View.VISIBLE
                flowbar="21230-17-2059987-0-%"
            }
            get_flow()
        }
        /*預設值*/
            color_direction="rigth"
            facrory="1"
            mStatus="0"
            cow="0"
            super_check="0"
            val saveip = getPreferences(MODE_PRIVATE)
            ip = saveip.getString("ip", "")
            mail = saveip.getString("mail", "")
            dept = saveip.getString("dept", "")
            mail_list= mail
        /*預設值*/
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        val rootView = window.decorView.rootView
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        wifi.setOnClickListener{
            wifi_test()
        }
        btn_cow.setOnClickListener {
            val builder = androidx.appcompat.app.AlertDialog.Builder(this@MainActivity)
            builder.setMessage("合作")
            builder.setCancelable(false)
            builder.setPositiveButton("確認") { dialog, id ->
                cow="1"
                val scanIntegrator = IntentIntegrator(this)
                scanIntegrator.initiateScan()
            }
            builder.setNegativeButton("取消") { dialog, which -> }
            builder.show()
        }
        btn_setting.setOnClickListener {
            startActivity(Intent(this@MainActivity, setting::class.java))
        }
        btn_plating.setOnClickListener {
            startActivity(Intent(this@MainActivity, platingActivity::class.java))
        }
        btn_editflow.setOnClickListener {
            startActivity(Intent(this@MainActivity, editflowActivity::class.java))
        }
        test_cnt_btn.setOnClickListener{
            DialogPrdtest().show(supportFragmentManager, "MyCustomFragment")
        }
        out_chk_btn.setOnClickListener{
            startActivity(Intent(this@MainActivity, Dialogoutcheck_1::class.java))
        }
        btn_Inquire.setOnClickListener{
            startActivity(Intent(this@MainActivity, InquireActivity::class.java))
        }
        bnt_selectMachins.setOnClickListener{
            startActivity(Intent(this@MainActivity, select_Machins::class.java))
        }
        btn_material_issue.setOnClickListener{
            DialogMaterialIssue().show(supportFragmentManager, "MyCustomFragment")
        }
        out_chk_def_btn.setOnClickListener{
            startActivity(Intent(this@MainActivity, DialogChkdef::class.java))
        }
        btn_colorsearch.setOnClickListener{
            startActivity(Intent(this@MainActivity, colorsearchActivity::class.java))
        }
        sance_btn.setOnClickListener{
            val scanIntegrator = IntentIntegrator(this)
            scanIntegrator.initiateScan()
        }
        //不良品入庫
        btn_wherehouse_def.setOnClickListener {
            try {
                val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
                val quant=DefectQuan_edit.text.toString()
                if(quant==""){
                    ui_Helper.mesage("請輸入入庫數量", this@MainActivity)
                }else{
                    Dialogsemidef().show(supportFragmentManager, "MyCustomFragment")
                }
            } catch (ex: Exception) {
            }
        }
        //良品入庫
        btn_wherehouse_semi.setOnClickListener {
            try {
                val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
                val quant=DefectQuan_edit.text.toString()
                if(quant==""){
                    ui_Helper.mesage("請輸入入庫數量", this@MainActivity)
                }else{
                    Dialogsemioutput().show(supportFragmentManager, "MyCustomFragment")
                }
            } catch (ex: Exception) {
            }
        }
        //拆單
        btn_spilt.setOnClickListener {
            val rootView = window.decorView.rootView
            val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
            try {
                var floatsplitQuan : Float = splitQuan.text.toString().toFloat();
                var floatinput : Float = InputQuan.toString().toFloat();
                if (floatsplitQuan>=floatinput){
                    ui_Helper.mesage("拆單量超過可拆數量", this@MainActivity)
                }else{
                    try {
                        var webapiClient = WebapiClient()
                        var url=MainActivity.ip+
                                "PrdMgn/ScanOperate?command=35&UID=" + MainActivity.userBar +
                                "&splitQuan=" +(splitQuan.text.toString())+
                                "&flowBar=" + MainActivity.flowbar +
                                "&DEPT=" + MainActivity.dept +
                                "&MID=" + MainActivity.machineBar +
                                "&jsonStr=" + MainActivity.flow_json
                        var jsonString:String?=webapiClient.requestPOST(url, JSONObject())
                        val jsonStr = JSONObject(jsonString)
                        val rtnData =  JSONObject(jsonStr.getString("Data"))
                        flow_message="已拆單 速碼: "+rtnData.getString("SUBFLOWID")
                        mainmessage.text=flow_message
                        ui_Helper.mesage(flow_message, this@MainActivity)
                        test_flow.performClick()
                    }catch (ex: Exception){
                    }
                }
            }catch (ex: Exception){
            }
        }
        shift_bnt.setOnClickListener {
            startActivity(Intent(this@MainActivity, shift_flow::class.java))
        }
        btn_getspilinfo.setOnClickListener {//選取拆單
            Dialoglist().show(supportFragmentManager, "MyCustomFragment")
        }
        change_Status.setOnClickListener {
            try {
                if(mStatus=="0"){
                    mStatus="2"
                }else{
                    mStatus="0"
                }
                var webapiClient = WebapiClient()
                var url=MainActivity.ip+
                        "PrdMgn/ScanOperate?command=10&UID=" + MainActivity.userBar + "&flowBar=" + MainActivity.flowbar +
                        "&DEPT=" + MainActivity.dept + "&MID=" + MainActivity.machineBar + "&mStatus="+ MainActivity.mStatus
                var jsonString:String?=webapiClient.requestPOST(url, JSONObject())
                val jsonStr = JSONObject(jsonString)
            }catch (ex: Exception){
            }
        }
        btn_shortSubFlow.setOnClickListener {
            try {
                var SubflowInfo = CustomLayoutSubflowInfo(this@MainActivity, null)
                var webapiClient = WebapiClient()
                var cmd=0
                if (dept.indexOf("貼") > -1) {
                    cmd=30
                }
                var url = MainActivity.ip +"PrdMgn/ScanOperate?command=0&UID=" + userBar +                        "&DEPT=" + MainActivity.dept + "&shortSubFlow=" + shortSubFlow.text
                if (shortSubFlow.text.indexOf("%") > -1) {
                    url = MainActivity.ip +
                            "PrdMgn/ScanOperate?command=$cmd&UID=" + userBar +
                            "&DEPT=" + MainActivity.dept + "&flowBar=" + shortSubFlow.text
                }else{
                     url = MainActivity.ip +
                            "PrdMgn/ScanOperate?command=$cmd&UID=" + userBar +
                            "&DEPT=" + MainActivity.dept + "&shortSubFlow=" + shortSubFlow.text
                }
                var jsonString:String?=webapiClient.requestPOST(url, JSONObject())
                val jsonStr = JSONObject(jsonString)
                flow_message=jsonStr.getString("Message")
                if (flow_message=="查詢完成" ||flow_message=="掃描完成"){
                    val rtnData =  JSONObject(jsonStr.getString("Data"))
                    flow_json= JSONObject(jsonStr.getString("Data"))
                    SubflowInfo.inputViewItems(flow_json, rootView)
                }else {
                    val array = JSONArray(jsonStr.optString("Data"))
                    val barCodeArray = JSONArray()
                    for (i in 0 until array.length()) {
                        val jsonObject = array.getJSONObject(i)
                        val MASTER_MFO_ID = jsonObject.getString("MASTER_MFO_ID")
                        val RTYPE = jsonObject.getString("RTYPE")
                        val VAL = jsonObject.getString("VAL")
                        val Tol = jsonObject.getString("Tol")
                        val batchNo = jsonObject.getString("batchNo")
                        val barCode = jsonObject.getString("barCode")
                        if (MASTER_MFO_ID!= "null")
                            barCodeArray.put(MASTER_MFO_ID + "  |  " + batchNo + "  |  " + VAL + "  |  " + Tol + "  |  " + RTYPE + "                                                                                      ///" + barCode)
                    }
                }
            }catch (ex: Exception){
                mainmessage.text=MainActivity.flow_message
            }
        }
        btn_dept_sw.setOnClickListener {
            if (sw_dept=="花蓮底漆"){
                btn_dept_sw.text="花蓮色碼"
                sw_dept="花蓮色碼"
            }else{
                btn_dept_sw.text="花蓮底漆"
                sw_dept="花蓮底漆"
            }
        }
        if(!flowbar.equals("")){
            test_flow.performClick();
        }
        if(!userBar.equals("")){
            //login()
            val rootView = window.decorView.rootView
            val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
            ui_Helper.login(User_json, rootView, this@MainActivity)
            info_textView.setText("部門:$DEPT\t\t\t員工:$EMPNAME\t\t\t  目前製程 : " + MainActivity.dept)
        }
        // Get the Intent that started this activity and extract the string
        try {
            val out_chk_btn = findViewById<Button>(R.id.out_chk_btn).apply {
                if (select_user!="")text = select_user
            }
            val input_edit = findViewById<EditText>(R.id.input_edit).apply {
                //外檢user input quant
                val regEx = "[^0-9]"
                val p: Pattern = Pattern.compile(regEx)
                val m: Matcher = p.matcher(select_user)
                System.out.println(m.replaceAll("").trim())
                val t=m.replaceAll("").trim().toString()
                input_edit.setText(t)
            }
            val DefectQuan_edit = findViewById<TextView>(R.id.DefectQuan_edit).apply {
                text = NG_SUM
            }
            val mid = findViewById<TextView>(R.id.mid_text).apply {
                text = machineBar
            }
        }catch (ex: Exception){}

        Supervisor_check.setOnClickListener{
            super_check="1"
            val scanIntegrator = IntentIntegrator(this)
            scanIntegrator.initiateScan()
        }
    }
    fun getAppContext(): Context? {
        return MainActivity.context
    }

    public fun get_flow_forselect(){
        val rootView = window.decorView.rootView
        val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
        try{
            var SubflowInfo = CustomLayoutSubflowInfo(this@MainActivity, null)
            var flow_json=ui_Helper.get_subflowInfo_by_short(str_shortSubFlow, userBar, dept, rootView, this@MainActivity)
            SubflowInfo.inputViewItems(flow_json, rootView)
        }catch (ex: Exception){
        }
        mainmessage.text=MainActivity.flow_message
    }
    private fun wifi_test() {
        val wifiManager = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager

        wifiManager.setWifiEnabled(false);
        Thread.sleep(1000);
        wifiManager.setWifiEnabled(true);
        var count = 0
        while (!wifiManager.isWifiEnabled) {
            if (count >= 10) {
                Log.i("TAG", "Took too long to enable wi-fi, quitting")
                return
            }
            Log.i("TAG", "Still waiting for wi-fi to enable...")
            try {
                Thread.sleep(1000L)
            } catch (ie: InterruptedException) {
                // continue
            }
            count++
        }
        wifi_test2()
    }

    private fun wifi_test2() {
        Thread.sleep(5000);
        val rootView = window.decorView.rootView
        val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
        try {
            var SubflowInfo = CustomLayoutSubflowInfo(this@MainActivity, null)
            var webapiClient = WebapiClient()

            var url = "http://172.168.1.33:1111/firstohmWebApi/ProdFlow/TestConnection"
            var jsonString:String?=webapiClient.requestPOST(url, JSONObject())
            val jsonStr = JSONObject(jsonString)
            flow_message=jsonStr.getString("Message")

            if (flow_message.equals("連線成功")){
                ui_Helper.mesage("連線成功", this@MainActivity);
            }else{
                ui_Helper.mesage("連線失敗請重試", this@MainActivity);
            }
        }catch (ex: Exception){
            ui_Helper.mesage("連線失敗請重試", this@MainActivity);
        }
    }
    private fun get_flow() {
        val rootView = window.decorView.rootView
        val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
        try{
            var SubflowInfo = CustomLayoutSubflowInfo(this@MainActivity, null)
            var flow_json=ui_Helper.get_subflowInfo(flowbar, userBar, dept, rootView, this@MainActivity)
            SubflowInfo.inputViewItems(flow_json, rootView)
        }catch (ex: Exception){
            ui_Helper.mesage(flow_message, this@MainActivity)

        }
        mainmessage.text=MainActivity.flow_message
    }
    private fun check_super(){
        try {
            var json = JSONObject()
            var webapiClient = WebapiClient()
            var rootView = window.decorView.rootView
            var ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
            var jsonString:String?=webapiClient.requestPOST(ip + "PrdMgn/Witness?UID=" + res_witness
                    + "&DEPT=" + MainActivity.dept + "&facroryNo=1&ifLeader=0&flowBar=" + flowbar, json)
            var jsonStr = JSONObject(jsonString)
            var Message = jsonStr.getString("Message")
            if (Message == "通過見證人驗證") {
                ifLeader = "1"
                ifLeader_forinput = "1"
            }
        }catch (ex: Exception){
        }
    }
    private fun login() {
        try {
            var sharedPref : SharedPreferences = this.getPreferences(Context.MODE_PRIVATE);
            sharedPref.edit().putString("ip", MainActivity.ip).commit()
            sharedPref.edit().putString("dept", MainActivity.dept).commit()
            sharedPref.edit().putString("mail", mail.toString()).commit()
            sharedPref.edit().putString("facrory", facrory.toString()).commit()
            sharedPref.edit().apply();
            var json = JSONObject()
            var webapiClient = WebapiClient()
            val rootView = window.decorView.rootView
            val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
            var jsonString:String?=webapiClient.requestPOST(ip + "PrdMgn/Login?userBar=" + userBar +
                    "&Dept=" + MainActivity.dept + "&facroryNo=" + facrory, json)
            var jsonStr = JSONObject(jsonString)
            User_json=jsonStr
            ui_Helper.login(jsonStr, rootView, this@MainActivity)
            mainmessage.text=MainActivity.flow_message
        }catch (ex: Exception){
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        try {
            val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
            if (result != null) {
                if (result.contents == null) {
                } else {
                    try {
                        val obj = result.getContents()
                        if (obj.indexOf("*") > -1&&super_check=="0"&&cow=="0") {
                            userBar = obj
                            userBar.replace("*", "")
                            login()
                        }else if (obj.indexOf("*") >= -1&&cow=="1"&&super_check=="0"){//合作
                            cow="0"
                            cow_user=obj
                            cow_user.replace("*", "")
                            cow_login()
                        }else if (obj.indexOf("*") > -1&&super_check=="1"&&cow=="0"){//見證
                            super_check="0"
                            res_witness=obj
                            check_super()
                        }else if (obj.indexOf("%") > -1) {
                            flowbar = obj
                            get_flow()
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            } else {
                super.onActivityResult(requestCode, resultCode, data)
            }
        }catch (ex: Exception){
        }
    }
    private fun cow_login(){//合作登入
        try {
            var json = JSONObject()
            var webapiClient = WebapiClient()
            val rootView = window.decorView.rootView
            val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
            var jsonString:String?=webapiClient.requestPOST(ip + "PrdMgn/Login?userBar=" +
                    cow_user + "&Dept=" + dept + "&facroryNo=1&coworker=" + cow_user, json)//+"&coworker=1"
            var jsonStr = JSONObject(jsonString)
            btn_cow.setBackgroundResource(R.mipmap.ic_cow_on)
            val rtnData =  JSONArray(jsonStr.getString("Data"))
            val jsonStrD = JSONObject(rtnData[0]?.toString())
            ui_Helper.mesage("   目前合作: " + jsonStrD?.getString("EMPNAME"), this@MainActivity)
            info_textView.text=info_textView.text.toString()+"目前合作: "+jsonStrD?.getString("EMPNAME")
        }catch (ex: Exception){
            cow_user=""
        }
    }
    companion object{
        private lateinit var context: Context
        fun setContext(con: Context) {
            context=con
        }
        var ip: String = String()
        var confirmed: String = String()
        var flow_message: String = String()
        var sw_dept: String = String()
        var machineBar: String = String()
        var dept: String = String()
        var flow_json: JSONObject = JSONObject()
        var User_json: JSONObject = JSONObject()
        var userBar: String = String()
        var SIGNID: String = String()
        var flowbar: String = String()
        var InputQuan: String = String()
        var tdRollQty: String = String()
        var mail: String = String()
        var color_direction: String = String()
        var midlist = ArrayList<String>()
        var mail_list : String = String()
        var material_issue = ArrayList<String>()
        var select_user: String = String()
        var check_out_input: String = String()
        var FLOW_STEP_CURR: String = String()
        var check_userid: String = String()
        var NG_SUM: String = String()
        var seach: String = String()
        var ng: String = String()
        var mStatus: String = String()
        var colorUser: String = String()
        var super_check: String = String()
        var FLOW_STEP: String = String()
        var res_witness: String = String()
        var ifLeader: String = String()
        var ifLeader_forinput: String = String()
        var input_edit: String = String()
        var splitID: String = String()
        var str_shortSubFlow: String = String()
        var VAL: String = String()
        var TOL: String = String()
        var PPM: String = String()
        var defectQuan: String = String()
        var output: String = String()
        var cow: String = String()
        var cow_user: String = String()
        var mfo_id: String = String()
        var BATCH_NO: String = String()
        var DEPT: String = String()
        var EMPNAME: String = String()
        var BATSEQ: String = String()
        var SIGNID_Edit: String = String()
        var facrory: String = String()
        var AccQuan: String = String()
        var StepLeft: String = String()
    }
    private fun readCpuInfo():String{

        val sb = StringBuffer();
        sb.append("abi: ").append(Build.CPU_ABI).append("\n");

        if (File("/proc/cpuinfo").exists()) {
            try {
                //val br =  BufferedReader(FileReader(File("/proc/cpuinfo")));
                val file = File("/proc/cpuinfo")

                file.bufferedReader().forEachLine {
                    sb.append(it + "\n");
                }

            } catch (e: IOException) {
                e.printStackTrace();
            }
        }
        return sb.toString();
    }

}