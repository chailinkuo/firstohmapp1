package com.example.firstohm_produce_kotlin

import android.content.Context
import android.util.AttributeSet
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_edit_flow.view.*
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.custom_layout_info.view.*
import kotlinx.android.synthetic.main.custom_layout_main_button.view.*
import kotlinx.android.synthetic.main.custom_layout_quant_color.view.*
import kotlinx.android.synthetic.main.custom_layout_quant_input.view.*
import kotlinx.android.synthetic.main.custom_layout_quant_input.view.output_edit
import kotlinx.android.synthetic.main.dialog_last_finsh.view.*
import org.json.JSONArray
import org.json.JSONObject
import java.lang.Float.parseFloat

class CustomLayoutSubflowInfo(
        context: Context,
        attrs: AttributeSet? = null
) : LinearLayout(context, attrs) {
    init {
        inflate(context, R.layout.custom_layout_info, this)
        val customAttributesStyle = context.obtainStyledAttributes(
                attrs,
                R.styleable.custom_layout_info,
                0,
                0
        )
        val textView_mfo_id = findViewById<TextView>(R.id.textView_mfo_id_value)
    }
    //write layout
    public fun inputViewItems(jsonObj: JSONObject, view: View){
        view.textView_mfo_id_value.setText(jsonObj.getString("mfo_id"))
        var BATCH_NO=jsonObj.getString("BATCH_NO")
        var BATSEQ: Int = Integer.valueOf(jsonObj.getString("BATSEQ"))
        MainActivity.BATCH_NO=jsonObj.getString("BATCH_NO")
        MainActivity.BATSEQ=jsonObj.getString("BATSEQ")
        MainActivity.FLOW_STEP_CURR=jsonObj.getString("FLOW_STEP_CURR")
        MainActivity.SIGNID=jsonObj.getString("SIGNID")
        MainActivity.InputQuan=jsonObj.getString("InputQuan")
        MainActivity.mfo_id=jsonObj.getString("mfo_id")
        MainActivity.flowbar=jsonObj.getString("barCode")
        MainActivity.VAL=jsonObj.getString("VAL")
        MainActivity.FLOW_STEP=jsonObj.getString("FLOW_STEP")
        MainActivity.TOL=jsonObj.getString("TOL")
        MainActivity.PPM=jsonObj.getString("PPM")
        MainActivity.AccQuan=jsonObj.getString("AccQuan")
        MainActivity.StepLeft=jsonObj.getString("StepLeft")
        var USER_ID_Befor=jsonObj.getString("USER_ID")
        BATSEQ = BATSEQ + 1
        view.BATCH_NO_text_value.setText("  $BATSEQ / $BATCH_NO")
        view.BATCH_QTY_text_value.setText(jsonObj.getString("BATCH_QTY"))
        view.RTYPE_text_value.setText(jsonObj.getString("RTYPE"))
        view.TOL_text_value.setText("  ±" + jsonObj.getString("TOL") + "%")
        view.input_edit.setEnabled(true);
        view.input_edit.setText(jsonObj.getString("InputQuan"))
        view.input_edit.setEnabled(false)
        if (MainActivity.dept=="花蓮貼帶"){
            MainActivity.tdRollQty=jsonObj.getString("tdRollQty")
        }
        var START_TIME=jsonObj.getString("Start_TIME")
        START_TIME = START_TIME.replace("\\/Date\\(".toRegex(), "")
        START_TIME = START_TIME.replace("\\)/".toRegex(), "")
        var Finish_Time=jsonObj.getString("Finish_Time")
        Finish_Time = Finish_Time.replace("\\/Date\\(".toRegex(), "")
        Finish_Time = Finish_Time.replace("\\)/".toRegex(), "")

        if (parseFloat(START_TIME)>0 &&parseFloat(Finish_Time)<0){
            view.btn_wherehouse_semi.visibility=View.VISIBLE
            view.btn_wherehouse_def.visibility=View.VISIBLE
            view.test_cnt_btn.visibility=View.VISIBLE
            view.flow_finsh__btn.visibility=View.VISIBLE
            view.flow_start_btn.visibility=View.INVISIBLE
            if (MainActivity.dept.indexOf("切")>-1)
                view.part_finsh_btn.visibility=View.VISIBLE
            else
                view.part_finsh_btn.visibility=View.INVISIBLE

        }else{
            view.btn_wherehouse_semi.visibility=View.INVISIBLE
            view.btn_wherehouse_def.visibility=View.INVISIBLE
            view.test_cnt_btn.visibility=View.INVISIBLE
            view.flow_finsh__btn.visibility=View.INVISIBLE
            view.part_finsh_btn.visibility=View.INVISIBLE
            view.flow_start_btn.visibility=View.VISIBLE
        }
        if (USER_ID_Befor !=MainActivity.userBar) {  //單與操作不同人直接給開始
            view.btn_wherehouse_semi.visibility=View.INVISIBLE
            view.btn_wherehouse_def.visibility=View.INVISIBLE
            view.test_cnt_btn.visibility=View.INVISIBLE
            view.flow_finsh__btn.visibility=View.INVISIBLE
            view.part_finsh_btn.visibility=View.INVISIBLE
            view.flow_start_btn.visibility=View.VISIBLE
        }
        if(jsonObj.getString("COLOR_NUM")!=""){
            try{
                val color = custom_layout_color(context, null)
                color.draw_color(jsonObj.getString("COLOR_NUM"), view)
            } catch (t: Throwable) {
            }
        }
        if(jsonObj.getString("dy_msgdy_msg")!="null"){
            try{
                val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
                ui_Helper.mesage(jsonObj.getString("dy_msgdy_msg"), context)
            } catch (t: Throwable) {}
        }
        if(jsonObj.getString("popMsg")!="null"){
            try{
                val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
                ui_Helper.mesage(jsonObj.getString("dy_msgdy_msg"), context)
            } catch (t: Throwable) {}
        }
    }
}