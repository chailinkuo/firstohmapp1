package com.example.firstohm_produce_kotlin

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.appcompat.app.AppCompatActivity
import co.ubunifu.kotlinhttpsample.Lib.WebapiClient
import com.example.firstohm_produce_kotlin.MainActivity.Companion.userBar
import com.google.zxing.integration.android.IntentIntegrator
import kotlinx.android.synthetic.main.activity_shift_layout.*
import kotlinx.android.synthetic.main.dialog_outcheck_ng.*
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

class shift_flow : AppCompatActivity() {
    var sourceBar=""
    var targetBar=""
    var sance_flag=1
    var t_flow=JSONObject()
    var jsonStrD=JSONObject()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shift_layout)
        this.supportActionBar?.hide()
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        val rootView = window.decorView.rootView
        val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
        sance_source.setOnClickListener{
            sance_flag=2
            val integrator = IntentIntegrator(this@shift_flow)
            integrator.initiateScan()
        }
        sance_tage.setOnClickListener{
            sance_flag=2
            val integrator = IntentIntegrator(this@shift_flow)
            integrator.initiateScan()
        }
        sance1.setOnClickListener {//左邊LAYOUT
            try {
                var webapiClient = WebapiClient()
                var url=MainActivity.ip+"PrdMgn/getTiedaiLeftInfo?flowBar="+sourceBar
                var jsonString:String?=webapiClient.requestPOST( "$url", JSONObject())
                val jsonStr = JSONObject(jsonString)
                val rtnData =  JSONArray(jsonStr.getString("Data"))
                jsonStrD = JSONObject(rtnData[0]?.toString())
                t_flow= jsonStrD
                val MASTER_MFO_ID = jsonStrD?.getString("MASTER_MFO_ID")
                val RTYPE = jsonStrD?.getString("RTYPE")
                val VAL = jsonStrD?.getString("VAL")
                val TOL = jsonStrD?.getString("TOL")
                val SIZE = jsonStrD?.getString("SIZE")
                val tieDaiQuant = jsonStrD?.getString("tieDaiQuant")
                val leftQty = jsonStrD?.getString("leftQty")
                Text_L1.setText("\t\t工令單號$MASTER_MFO_ID".trimIndent())
                Text_L2.setText("\t\t型號\t\t\t\t\t\t$RTYPE".trimIndent())
                Text_L3.setText("\t\t阻值\t\t\t\t\t\t$VAL".trimIndent())
                Text_L4.setText("\t\tTOL\t\t\t\t\t\t\t$TOL".trimIndent())
                Text_L5.setText("\t\t尺寸\t\t\t\t\t\t$SIZE".trimIndent())
                Text_L6.setText("\t\t已貼數量\t\t\t\t\t\t$tieDaiQuant".trimIndent())
                Text_L7.setText("\t\t餘料數量\t\t\t\t\t\t$leftQty".trimIndent())
            }catch (ex: Exception){}
        }
        sance2.setOnClickListener {  //右邊LAYOUT
            try {
                var webapiClient = WebapiClient()
                var url=MainActivity.ip+"PrdMgn/getTiedaiInfo?flowBar="+targetBar
                var jsonString:String?=webapiClient.requestPOST("$url", JSONObject())
                val jsonStr = JSONObject(jsonString)
                val rtnData =  JSONArray(jsonStr.getString("Data"))
                jsonStrD = JSONObject(rtnData[0]?.toString())
                val MASTER_MFO_ID = jsonStrD?.getString("MASTER_MFO_ID")
                val RTYPE = jsonStrD?.getString("RTYPE")
                val VAL = jsonStrD?.getString("VAL")
                val TOL = jsonStrD?.getString("Tol")
                val SIZE = jsonStrD?.getString("SIZE")
                val tieDaiQuant = jsonStrD?.getString("tieDaiQuant")
                val leftQty = jsonStrD?.getString("leftQty")
                text_R1.setText("\t\t工令單號$MASTER_MFO_ID".trimIndent())
                text_R2.setText("\t\t型號\t\t\t\t\t\t$RTYPE".trimIndent())
                text_R3.setText("\t\t阻值\t\t\t\t\t\t$VAL".trimIndent())
                text_R4.setText("\t\tTOL\t\t\t\t\t\t\t$TOL".trimIndent())
                text_R5.setText("\t\t尺寸\t\t\t\t\t\t$SIZE".trimIndent())
                text_R6.setText("\t\t貼帶數量\t\t\t\t\t\t$tieDaiQuant".trimIndent())
                text_R7.setText("\t\t餘料數量\t\t\t\t\t\t$leftQty".trimIndent())
            }catch (ex: Exception){}
        }
        btn_Finished_Warehousing.setOnClickListener{
            try {
                t_flow.put("tieDaiQuant",submit_text1.text.toString())
                var webapiClient = WebapiClient()
                var url=MainActivity.ip+"PrdMgn/ScanOperate?" +
                        "command=37&UID="+MainActivity.userBar+
                        "&flowBar="+MainActivity.flowbar+"&DEPT="+ MainActivity.dept+
                        "&jsonStr=" +t_flow.toString()
                var jsonString:String?=webapiClient.requestPOST("$url", JSONObject())
                val jsonStr = JSONObject(jsonString)
                ui_Helper.mesage(jsonStr.getString("Message"), this@shift_flow)
                val rtnData =  JSONObject(jsonStr.getString("Data"))
            }catch (ex: Exception){

            }
        }
        shiftbnt.setOnClickListener{
            try {
                var webapiClient = WebapiClient()
                var url=MainActivity.ip+
                        "PrdMgn/" +
                        "shiftTiedai?sourceBar=" + sourceBar +
                        "&targetBar=" + targetBar +
                        "&shifQuant=" + submit_text1.text + "&empID=" + MainActivity.userBar
                var jsonString:String?=webapiClient.requestPOST("$url", JSONObject())
                val jsonStr = JSONObject(jsonString)
                ui_Helper.mesage(jsonStr.getString("Message"), this@shift_flow)
            }catch (ex: Exception){

            }
        }
        shiftbnt_out.setOnClickListener{
            try {
                var webapiClient = WebapiClient()
                var url=MainActivity.ip+
                        "PrdMgn/" +
                        "shiftTiedai?sourceBar="  + targetBar +
                        "&targetBar=" + sourceBar+
                        "&shifQuant=" + submit_text1.text + "&empID=" + MainActivity.userBar
                var jsonString:String?=webapiClient.requestPOST("$url", JSONObject())
                val jsonStr = JSONObject(jsonString)
                ui_Helper.mesage(jsonStr.getString("Message"), this@shift_flow)
            }catch (ex: Exception){

            }
        }
        if (MainActivity.flowbar!=""){
            try {
                var webapiClient = WebapiClient()
                var url=MainActivity.ip+"PrdMgn/getTiedaiLeftInfo?flowBar="+MainActivity.flowbar
                var jsonString:String?=webapiClient.requestPOST(
                        "$url", JSONObject())
                val jsonStr = JSONObject(jsonString)
                val rtnData =  JSONArray(jsonStr.getString("Data"))
                val jsonStrD = JSONObject(rtnData[0]?.toString())
                t_flow= jsonStrD
                val MASTER_MFO_ID = jsonStrD?.getString("MASTER_MFO_ID")
                val RTYPE = jsonStrD?.getString("RTYPE")
                val VAL = jsonStrD?.getString("VAL")
                val TOL = jsonStrD?.getString("TOL")
                val SIZE = jsonStrD?.getString("SIZE")
                val leftQty = jsonStrD?.getString("leftQty")
                Text_L1.setText("工令單號\t\t\t\t\t\t$MASTER_MFO_ID".trimIndent())
                Text_L2.setText("型號\t\t\t\t\t\t$RTYPE".trimIndent())
                Text_L3.setText("阻值\t\t\t\t\t\t$VAL".trimIndent())
                Text_L4.setText("TOL\t\t\t\t\t\t\t$TOL".trimIndent())
                Text_L5.setText("尺寸\t\t\t\t\t\t$SIZE".trimIndent())
                Text_L6.setText("".trimIndent())
                submit_text1.setText(leftQty)
            }catch (ex: Exception){}
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        try {
            val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
            if (result != null) {
                if (result.contents == null) {
                } else {
                    try {
                        val obj = result.getContents()
                        if (obj.indexOf("%") >= -1) {
                            if (sance_flag==1){
                                sourceBar=obj
                                sance1.performClick();
                            }else{
                                targetBar=obj
                                sance2.performClick();
                            }
                        }
                    } catch (e: JSONException) {
                        e.printStackTrace()
                    }
                }
            } else {
                super.onActivityResult(requestCode, resultCode, data)
            }
        }catch (ex: Exception){
        }
    }
}