package com.example.firstohm_produce_kotlin

import android.content.Context
import android.graphics.Color
import android.text.Editable
import android.text.TextWatcher
import android.util.AttributeSet
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import androidx.core.*
import co.ubunifu.kotlinhttpsample.Lib.WebapiClient
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.custom_layout_quant_input.view.*
import org.json.JSONObject

class custom_layout_quant_input(
        context: Context,
        attrs: AttributeSet
) : LinearLayout(context, attrs) {
    init {
        inflate(context, R.layout.custom_layout_quant_input, this)
        val customAttributesStyle = context.obtainStyledAttributes(
                attrs,
                R.styleable.custom_layout_quant_input,
                0,
                0
        )
        btn_editinput.setOnClickListener {
            input_edit.setEnabled(true);
        }

        get_machins.setOnClickListener {
            val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
            var url = MainActivity.ip + "PrdMgn/ScanOperate?command=8&UID=" +
                    MainActivity.userBar + "&MID=" + MainActivity.machineBar +
                    "&flowBar=" + MainActivity.flowbar + "&DEPT=" + MainActivity.dept + "&jsonStr=" + MainActivity.flow_json
            var webapiClient = WebapiClient()
            var jsonString: String? = webapiClient.requestPOST(url, JSONObject())
            var json = JSONObject(jsonString)
            try {
                var json_Data = JSONObject(json.getString("Data"))
                val SubflowInfo = CustomLayoutSubflowInfo(context, null)
                SubflowInfo.inputViewItems(json_Data, rootView)
            } catch (ex: Exception) {
                ui_Helper.mesage(json.getString("Message"), context)
            }
        }
        Radio_tdqty.setOnClickListener {
            rootView.input_edit.setText(MainActivity.InputQuan)
        }
        Radio_tdroll.setOnClickListener {
            try {
                val roll : Float = MainActivity.tdRollQty.toFloat();
                val input : Float = MainActivity.InputQuan.toFloat();
                val sum=input/(roll*1000)
                rootView.input_edit.setText(sum.toString())
            } catch (ex: Exception) {
                Log.d("1", ex.message)
            }
        }
        Supervisor_check.setOnClickListener{
            MainActivity.super_check="1"
        }
        TieDaiL_check.setOnClickListener{
            try {
                if (TieDaiL_check.isChecked) {
                    shift_bnt.visibility = VISIBLE
                    DefectQuan_edit.setText("0")
                    DefectQuan_edit.setFocusable(false)
                    DefectQuan_edit.setBackgroundColor(Color.parseColor("#BFBFBF"))
                } else {
                    shift_bnt.visibility = GONE
                    DefectQuan_edit.setFocusableInTouchMode(true)
                    DefectQuan_edit.setFocusable(true)
                    DefectQuan_edit.setBackgroundColor(Color.WHITE)
                }
            } catch (ex: Exception) {
                Log.d("1", ex.message)
            }
        }
        DefectQuan_edit.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                try {
                    val input = input_edit.text.toString().toFloat()
                    val output = output_edit.text.toString().toFloat()
                    val DefectQuan = DefectQuan_edit.text.toString().toFloat()
                    var sum = input - output - DefectQuan
                    if (sum <= 0)
                        sum = 0F
                    val sum1 = sum.toInt()
                    StepLeft_edit.setText(sum1.toString())
                    MainActivity.defectQuan = DefectQuan_edit.text.toString().toFloat().toString()
                } catch (ex: Exception) {
                    Log.d("1", ex.message)
                }
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })
        output_edit.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {

                try {
                    MainActivity.output = output_edit.text.toString().toFloat().toString()

                    val input = input_edit.text.toString().toFloat()
                    val output = output_edit.text.toString().toFloat()
                    val DefectQuan = DefectQuan_edit.text.toString().toFloat()
                    var sum = input - output - DefectQuan
                    if (sum <= 0)
                        sum = 0F
                    val sum1 = sum.toInt()
                    StepLeft_edit.setText(sum1.toString())
                } catch (ex: Exception) {
                    Log.d("1", ex.message)
                }
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

    }

    public fun get_m(view: View){
        mid_text.text=MainActivity.machineBar
    }
}