package com.example.firstohm_produce_kotlin

import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.view.WindowManager
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import co.ubunifu.kotlinhttpsample.Lib.WebapiClient
import kotlinx.android.synthetic.main.activity_setting_layout.*
import org.json.JSONObject

class setting: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting_layout)
        this.supportActionBar?.hide()  //hide title bar
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        restmid.text="將"+MainActivity.machineBar+"設為待機"
        if(MainActivity.ip=="http://172.168.1.33:1111/firstohmWebApi/"){
            radioButton_33.isChecked=true
        }else{
            radioButton_151.isChecked=true
        }
        cancel.setOnClickListener {
            finish()
        }
        restmid.setOnClickListener {

            var webapiClient = WebapiClient()
            var url=MainActivity.ip+
                    "PrdMgn/ScanOperate?command=10&UID=" + MainActivity.userBar + "&flowBar=" + MainActivity.flowbar +
                    "&DEPT=" + MainActivity.dept + "&MID=" + MainActivity.machineBar + "&mStatus=0"
            var jsonString:String?=webapiClient.requestPOST(url, JSONObject())
            val jsonStr = JSONObject(jsonString)
        }
        bnt_Mail.setOnClickListener {
            val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(it)
            ui_Helper.send_mail("請輸入入庫數量")
        }
        if (MainActivity.mail.indexOf("1")>-1){
            cb_mail_c004.isChecked=true
        }
        if (MainActivity.mail.indexOf("2")>-1){
            cb_mail_c002.isChecked=true
        }
        if (MainActivity.mail.indexOf("3")>-1){
            cb_mail_clkuo.isChecked=true
        }
        save.setOnClickListener {
            if(facroryNo_1.isChecked==true){
                MainActivity.facrory="1"
            }else{
                MainActivity.facrory="2"
            }
            if(input_edit.isChecked==true){
                MainActivity.input_edit="1"
            }else{
                MainActivity.input_edit="0"
            }
            if(radio_color_rigth.isChecked==true){
                MainActivity.color_direction="rigth"
            }else{
                MainActivity.color_direction="left"
            }
            if(radioButton_33.isChecked==true){
                MainActivity.ip="http://172.168.1.33:1111/firstohmWebApi/"
            }else{
                MainActivity.ip="http://172.168.1.151:1119/firstohmWebApi/"
            }
            MainActivity.dept=dept_spinner.getSelectedItem().toString()
            var mail =JSONObject()
            //email map
            if(cb_mail_c004.isChecked==true){
                mail.put("1","hualien")
            }
            if(cb_mail_c002.isChecked==true){
                mail.put("2","HL-WS")
            }
            if(cb_mail_clkuo.isChecked==true){
                mail.put("3","chailin.kuo")
            }
            MainActivity.mail=mail.toString()
            var sharedPref : SharedPreferences = this.getPreferences(Context.MODE_PRIVATE);
            sharedPref.edit().putString("ip", MainActivity.ip).commit()
            sharedPref.edit().putString("mail", mail.toString()).commit()
            sharedPref.edit().putString("dept", MainActivity.dept).commit()
            sharedPref.edit().apply();
            finish()
        }
        ArrayAdapter.createFromResource(
                this,
                R.array.dept,
                R.layout.obj_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(R.layout.obj_spinner_item)
            dept_spinner.adapter = adapter
        }
        dept_spinner.setSelection((dept_spinner.getAdapter() as ArrayAdapter<String?>).getPosition(MainActivity.dept))
    }
}