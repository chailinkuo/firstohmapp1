package com.example.firstohm_produce_kotlin

import androidx.appcompat.app.AppCompatActivity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.AlarmClock
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import co.ubunifu.kotlinhttpsample.Lib.WebapiClient
import com.example.firstohm_produce_kotlin.MainActivity.Companion.NG_SUM
import com.example.firstohm_produce_kotlin.MainActivity.Companion.check_out_input
import com.example.firstohm_produce_kotlin.MainActivity.Companion.check_userid
import com.example.firstohm_produce_kotlin.MainActivity.Companion.select_user
import kotlinx.android.synthetic.main.activity_machins_layout.*
import kotlinx.android.synthetic.main.custom_layout_quant_input.*
import kotlinx.android.synthetic.main.custom_layout_quant_input.view.*
import kotlinx.android.synthetic.main.dialog_outcheck_1_user.*
import kotlinx.android.synthetic.main.dialog_outcheck_ng.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.*
class DialogChkdef : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.dialog_outcheck_ng)
        this.supportActionBar?.hide()
        ng_submit.setOnClickListener {
            var ng1=Integer.valueOf(ng1_text.getText().toString());
            var ng2=Integer.valueOf(ng2_text.getText().toString());
            var ng3=Integer.valueOf(ng3_text.getText().toString());
            NG_SUM= (ng1+ng2+ng3).toString()
            MainActivity.NG_SUM=NG_SUM
            var webapiClient = WebapiClient()
            var url=MainActivity.ip+"PrdMgn/updOutCheckLog?"+
                    "flowBar="+MainActivity.flowbar+
                    "&NG1="+ng1+"&NG2="+ng2 +"&NG3="+ng3+
                    "&checkourSeq=1&signID="+MainActivity.SIGNID+
                    "&preOperatorID="+check_userid+"&jsonStr="+MainActivity.flow_json
            var jsonString:String?=webapiClient.requestPOST("$url", JSONObject())
            val jsonStr = JSONObject(jsonString)
            val intent = Intent(this, MainActivity::class.java).apply {
                putExtra(AlarmClock.EXTRA_MESSAGE, NG_SUM)
            }
            startActivity(intent)
            finish();
        }
    }
}