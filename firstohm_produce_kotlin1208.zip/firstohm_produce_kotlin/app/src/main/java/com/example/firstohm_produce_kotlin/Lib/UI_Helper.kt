package co.ubunifu.kotlinhttpsample.Lib

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.AdapterView
import android.widget.AdapterView.OnItemSelectedListener
import android.widget.ArrayAdapter
import android.widget.Spinner
import com.example.firstohm_produce_kotlin.MainActivity
import com.example.firstohm_produce_kotlin.R
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.view.*
import kotlinx.android.synthetic.main.custom_layout_info.view.*
import kotlinx.android.synthetic.main.custom_layout_main_button.view.*
import kotlinx.android.synthetic.main.custom_layout_quant_input.view.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.log


class UI_Helper(view: View){
    public fun mesage(rore: String, context: Context) {
        val builder =
            androidx.appcompat.app.AlertDialog.Builder(context)
        builder.setMessage(rore)
        builder.setCancelable(false)
        builder.setPositiveButton(
                "確認"
        ) { dialog, id -> }
        builder.show()
    }
    public fun retriveFromJsonStrn(jsonString: String, retriveItem: String? = null): Any? {
        var jsonObj = JSONObject(JSONObject(jsonString).getString("Data"))
        if(retriveItem==null)
            return jsonObj
        else
            return jsonObj.opt(retriveItem)
    }
    public fun jsonStrToObject(jsonString: String, elementName: String? = null): JSONObject? {
        return JSONObject(JSONObject(jsonString).getString(elementName ?: "Data"))
    }
    public fun get_subflowInfo(flow_bar: String, dept: String, user_bar: String, view: View, context: Context): JSONObject {
        val inflater = LayoutInflater.from(context)
        val v: View = inflater.inflate(R.layout.custom_layout_info, null)
        var webapiClient = WebapiClient()
        val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(view)
        var cmd=ui_Helper.get_sance_cmd(MainActivity.dept)
        var url=MainActivity.ip+"PrdMgn/ScanOperate?" +
                "command=$cmd&UID="+MainActivity.userBar+"&flowBar="+MainActivity.flowbar +
        "&DEPT="+ MainActivity.dept
        var jsonString:String?=webapiClient.requestPOST(
                "$url", JSONObject())
        val jsonStr = JSONObject(jsonString)
        MainActivity.flow_message=jsonStr.getString("Message")
        val rtnData =  JSONObject(jsonStr.getString("Data"))
        MainActivity.flow_json= JSONObject(jsonStr.getString("Data"))
        return rtnData
    }
    public fun get_subflowInfo_by_short(short: String, processName: String, user_bar: String, view: View, context: Context): JSONObject {
        val inflater = LayoutInflater.from(context)
        val v: View = inflater.inflate(R.layout.custom_layout_info, null)
        var webapiClient = WebapiClient()
        val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(v)
        var cmd=0
        if (MainActivity.dept.indexOf("貼") > -1) {
            cmd=30
        }
        var url = MainActivity.ip +
                "PrdMgn/ScanOperate?command=$cmd&UID=" + MainActivity.userBar +
                "&DEPT=" + MainActivity.dept + "&shortSubFlow=" + short
        var jsonString:String?=webapiClient.requestPOST("$url", JSONObject())
        val jsonStr = JSONObject(jsonString)
        MainActivity.flow_message=jsonStr.getString("Message")
        val rtnData =  JSONObject(jsonStr.getString("Data"))
        MainActivity.flow_json= JSONObject(jsonStr.getString("Data"))
        return rtnData
    }

    public fun login(jsonStr: JSONObject, view: View, context: Context){
        try {
            MainActivity.flow_message=jsonStr.getString("Message").toString()
            val rtnData =  JSONArray(jsonStr.getString("Data"))
            val jsonStrD = JSONObject(rtnData[0]?.toString())
            val Data_mid = jsonStrD?.getString("Machins")
            val DEPT = jsonStrD?.getString("DEPT")
            val EMPNAME = jsonStrD?.getString("EMPNAME")

            MainActivity.DEPT = jsonStrD?.getString("DEPT")
            MainActivity.EMPNAME = jsonStrD?.getString("EMPNAME")
            if(MainActivity.dept=="花蓮切割" || MainActivity.dept=="花蓮加壓"
               || MainActivity.dept=="花蓮外檢"|| MainActivity.dept=="花蓮全檢"){
                val array = JSONArray(Data_mid)
                val midlist = ArrayList<String>()
                for (j in 0 until array.length()) {
                    val Jasonobject: String = array.getString(j) //O
                    val array2 = JSONArray(Jasonobject) //o
                    for (k in 0 until array2.length()) {
                        val ob2 = array2.getJSONObject(k)
                        val mid = ob2.getString("mid")
                        var attr2 = ob2.getString("attr2")
                        val status = ob2.getString("status")
                        if (mid == "null") {
                            midlist.add("null")
                        } else {
                            //midlist.add(attr2 +"\n"+mid+"status"+status);
                            attr2 = attr2.replace("\\\\".toRegex(), "")
                            attr2 = attr2.replace("n".toRegex(), "  ")
                            midlist.add(attr2 + "  " + mid + "status" + status)
                        }
                    }
                    midlist.add("new")
                    MainActivity.midlist=midlist
                }
            }else{
                val Data_mid0 = jsonStrD?.getJSONArray("Machins")
                val mid_Array = JSONArray()
                for (j in 0 until Data_mid0.length()) {
                    val jsonObjectDates: JSONObject = Data_mid0.getJSONObject(j)
                    val mid = jsonObjectDates.getString("MachineID")
                    mid_Array.put(mid)
                }
                view.mid_spinner.visibility=View.VISIBLE
                view.bnt_selectMachins.visibility=View.GONE
                set_spinner_data(view.mid_spinner, context, mid_Array, null)
                view.mid_spinner.setOnItemSelectedListener(object : OnItemSelectedListener {
                    override fun onItemSelected(adapterView: AdapterView<*>?, view1: View, i: Int, l: Long) {
                        MainActivity.machineBar = view.mid_spinner.getSelectedItem().toString()
                    }

                    override fun onNothingSelected(adapterView: AdapterView<*>?) {
                        return
                    }
                })
            }
            val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
            val today = sdf.format(Date())
            view.info_textView.setText("部門:$DEPT\t\t\t員工:$EMPNAME\t\t\t  目前製程 : " + MainActivity.dept)
            ///////
            val ng_array = arrayOf(
                    "非重複性檢測", "NG1", "NG2", "NG3", "NG1+2", "NG1+3", "NG2+3", "NG1+2+3"
            )
            val ng_Array = JSONArray()
            for (j in 0 until ng_array.size) {
                ng_Array.put(ng_array[j])
            }
            set_spinner_data(view.NG_select, context, ng_Array, null)
            view.NG_select.setOnItemSelectedListener(object : OnItemSelectedListener {
                override fun onItemSelected(adapterView: AdapterView<*>?, view1: View, i: Int, l: Long) {
                    MainActivity.ng = i.toString()
                }

                override fun onNothingSelected(adapterView: AdapterView<*>?) {
                    return
                }
            })
            /////////////
            val terrible__array = arrayOf(
                    "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10次以上"
            )
            val terrible_Array = JSONArray()
            for (j in 0 until terrible__array.size) {
                terrible_Array.put(terrible__array[j])
            }
            set_spinner_data(view.terrible_spinner, context, terrible_Array, null)
            /////////////
            if (MainActivity.dept=="花蓮底漆"){
                view.terrible_layout.visibility=View.VISIBLE
                //view.part_finsh_btn.visibility=View.VISIBLE
            }else{
                view.terrible_layout.visibility=View.GONE
                view.part_finsh_btn.visibility=View.GONE
            }
            if (MainActivity.dept=="花蓮塗裝"){
                view.btn_dept_sw.visibility=View.VISIBLE
            }else{
                view.btn_dept_sw.visibility=View.GONE
            }
            if (MainActivity.dept=="花蓮貼帶"){
                view.tedai_layout.visibility=View.VISIBLE
                view.shift_bnt.visibility=View.VISIBLE
            }else{
                view.tedai_layout.visibility=View.GONE
                view.shift_bnt.visibility=View.GONE
            }
            if (MainActivity.dept=="花蓮色碼"){
                view.custom_layout_color.visibility=View.VISIBLE
            }else{
                view.custom_layout_color.visibility=View.GONE
            }
            if (MainActivity.dept=="花蓮外檢"){
                view.out_chk_btn.visibility=View.VISIBLE
                view.out_chk_def_btn.visibility=View.VISIBLE
                view.NG_select.visibility=View.VISIBLE
            }else{
                view.out_chk_btn.visibility=View.GONE
                view.out_chk_def_btn.visibility=View.GONE
                view.NG_select.visibility=View.GONE
            }
            if (MainActivity.dept=="花蓮加壓"||MainActivity.dept=="花蓮切割"){
                view.speed_layout.visibility=View.VISIBLE
                if (MainActivity.dept=="花蓮加壓"){
                    view.speed_text.text="電壓"
                }
                if (MainActivity.dept=="花蓮切割"){
                    view.speed_text.text="速度"
                }
            }else{
                view.speed_layout.visibility=View.GONE
            }
        }catch (ex: Exception){
            Log.d("1", ex.message)
        }
    }
    public fun set_spinner_data(targetSpiner: Spinner, context: Context, itemsList: JSONArray, defaulyVal: String?) {
        val list = Array(itemsList.length()) {
            itemsList.getString(it)
        }
        val arrayAdapter = ArrayAdapter(
                context,
                R.layout.simple_spinner_dropdown_item,
                list
        )
        arrayAdapter.setDropDownViewResource(R.layout.simple_spinner_dropdown_item);

        targetSpiner.adapter = arrayAdapter
        if(defaulyVal!=null) {
            //Todo 设定预设值
            targetSpiner.setSelection((targetSpiner.getAdapter() as ArrayAdapter<String?>).getPosition(defaulyVal))

        }
    }
    fun get_midinfo_cmd(start_text: String): String {
        var cmd="8"
        if (MainActivity.dept == "花蓮貼帶") {
            cmd="38"
        }
        if (MainActivity.dept == "花蓮外檢") {
            cmd="48"
        }
        return cmd
    }
    fun get_finsh_cmd(): String {
        var cmd="11"
        if (MainActivity.dept == "花蓮貼帶") {
            cmd="36"
        }
        if (MainActivity.input_edit=="1"){
            cmd="11"
        }
        return cmd
    }
    fun get_size(start_text: String): String? {
        val cmd_map = HashMap<String, String>()
        cmd_map["1x3.15"]="52000"
        cmd_map["1.7x5.4"]="12300"
        cmd_map["2.5x8"]="4400"
        cmd_map["3.5x10"]="1700"
        cmd_map["4x12"]="1300"
        cmd_map["4.5x14"]="1000"
        return cmd_map[start_text]
    }
    fun get_start_cmd(start_text: String): String {
        val cmd_map = HashMap<String, String>()
        if (MainActivity.dept == "花蓮貼帶") {
            cmd_map["開始新製程 Bắt đầu quy trình mới"]="31"
            cmd_map["開始新製程"]="31"
            cmd_map["接續前班"]="33"
            cmd_map["延續前班製程Tiếp tục ca trước"]="33"
            cmd_map["更換機台"]="34"
            cmd_map["更換機台作業thay đơi máy"]="34"
        }else{
            cmd_map["開始新製程 Bắt đầu quy trình mới"]="1"
            cmd_map["開始新製程"]="1"
            cmd_map["接續前班"]="3"
            cmd_map["延續前班製程Tiếp tục ca trước"]="3"
            cmd_map["更換機台作業thay đơi máy"]="4"
            cmd_map["更換機台"]="4"
        }
        cmd_map["換機開始"]="7"
        cmd_map["全檢1"]="15"
        cmd_map["全檢2"]="15"
        cmd_map["外檢驗底漆"]="21"  //外檢1
        cmd_map["外檢驗色碼"]="23"  //外檢2
        cmd_map["塗前加壓"]="24"
        cmd_map["底漆半成品"]="25"
        cmd_map["底漆完成品"]="27"
        cmd_map["外檢1"]="21"
        cmd_map["外檢2"]="23"
        cmd_map["全檢良品重測"]="22"
        cmd_map["全檢不良品重測"]="22"
        cmd_map["良品重測"]="22"
        cmd_map["不良品重測"]="22"
        cmd_map["全檢分類"]="1"
        cmd_map["分類"]="1"
        cmd_map["外檢1重測"]="28"
        cmd_map["外檢2重測"]="28"
        return cmd_map[start_text].toString()
    }
    fun get_sance_cmd(start_text: String): String {
        var cmd="0"
        if (MainActivity.dept.indexOf("外")>-1){
            cmd="13"
            if (MainActivity.ifLeader_forinput.indexOf("1")>-1){
                cmd="13A"
            }
        }else if (MainActivity.dept.indexOf("貼")>-1){
             cmd="30"
        }
        return cmd.toString()
    }
    fun send_mail(body: String): String{
        var webapiClient = WebapiClient()
        val jsonArray = JSONObject(MainActivity.mail)
        try {
            val name1 = jsonArray?.getString("1");
            var url="http://172.168.1.33:1111/firstohmWebApi/FirstohmAD/" +
                    "SendNotification?subject=APP通知&messagebody=$body&toUserLoginName=$name1"
            //var jsonString:String?=webapiClient.requestPOST("$url", JSONObject())
            Log.d("m",url)
        }catch (ex: Exception){}
        try {
            val name1 = jsonArray?.getString("2");
            var url="http://172.168.1.33:1111/firstohmWebApi/FirstohmAD/" +
                    "SendNotification?subject=APP通知&messagebody=$body&toUserLoginName=$name1"
            //var jsonString:String?=webapiClient.requestPOST("$url", JSONObject())
            Log.d("m",url)
        }catch (ex: Exception){}
        try {
            val name1 = jsonArray?.getString("3");
            var url="http://172.168.1.33:1111/firstohmWebApi/FirstohmAD/" +
                    "SendNotification?subject=APP通知&messagebody=$body&toUserLoginName=$name1"
            //var jsonString:String?=webapiClient.requestPOST("$url", JSONObject())
            Log.d("m",url)
        }catch (ex: Exception){}
        return body.toString()
    }
}

