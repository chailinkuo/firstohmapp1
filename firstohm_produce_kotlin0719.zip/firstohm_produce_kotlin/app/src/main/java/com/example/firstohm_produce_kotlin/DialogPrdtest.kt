package com.example.firstohm_produce_kotlin

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import co.ubunifu.kotlinhttpsample.Lib.WebapiClient
import com.example.firstohm_produce_kotlin.Lib.ListViewModelAdapterprd
import com.example.firstohm_produce_kotlin.Lib.ListViewModelRo
import com.google.gson.Gson
import kotlinx.android.synthetic.main.dialog_prd_test.*
import org.json.JSONObject
import java.util.*
import kotlin.collections.ArrayList


class DialogPrdtest: DialogFragment() {

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        //getDialog()!!.getWindow()?.setBackgroundDrawableResource(R.drawable.ic_launcher_background);
        return inflater.inflate(R.layout.dialog_prd_test, container, false)
    }

    override fun onStart() {
        super.onStart()
        var listViewModelArrayList = ArrayList<ListViewModelRo>()

        for (i in 0 until 9) {
            var listViewAdapter = ListViewModelAdapterprd(
                    this.context,
                    listViewModelArrayList as ArrayList<ListViewModelRo>
            )
            listViewModelArrayList.add(
                    ListViewModelRo(
                            "",
                            "",
                            "",
                            "",
                            "",
                            ""
                    )
            )
            listViewAdapter.notifyDataSetChanged()
            whare_house_list.adapter = listViewAdapter
            var listViewModelArrayList = ArrayList<ListViewModelRo>()
        }
        val width = 1000
        val height = 1000
        dialog!!.window?.setLayout(width, ViewGroup.LayoutParams.WRAP_CONTENT)
        btn_prd_submit.setOnClickListener {
            val roAdaptor = whare_house_list.adapter as ListViewModelAdapterprd
            val roListModelArrayList =  roAdaptor.getListViewModelList()
            val whIdxList = ArrayList<Int>()
            var submit_arr=ArrayList<String>()
            for(i in 0..roListModelArrayList.size-1)
            {
                submit_arr.add(roListModelArrayList[i].count_1.toString())
                submit_arr.add(roListModelArrayList[i].count_2.toString())
                submit_arr.add(roListModelArrayList[i].count_3.toString())
                submit_arr.add(roListModelArrayList[i].count_4.toString())
                submit_arr.add(roListModelArrayList[i].count_5.toString())
                submit_arr.add(roListModelArrayList[i].count_6.toString())
            }
            val refinedArray = arrayOfNulls<String>(submit_arr.size)
            var count = -1
            for (s in submit_arr) {
                if (s != "") { // Skips over null values. Add "|| "".equals(s)" if you want to exclude empty strings
                    refinedArray[++count] = s // Increments count and sets a value in the refined array
                }
            }
            val array = Arrays.copyOf(refinedArray, count + 1)
            val cnvJson = Gson().toJson(array)

            var webapiClient = WebapiClient()
            //val rootView = window.decorView.rootView
            val ui_Helper = co.ubunifu.kotlinhttpsample.Lib.UI_Helper(rootView)
            var jsonString:String?=webapiClient.requestPOST(MainActivity.ip +
                    "PrdMgn/SubmitFlowTest?SIGNID=" + SIGNID +
                    "&UID=" + encodedUr2 + "&flowBar="
                    + MainActivity.flowbar + "&DEPT=" + MainActivity.dept +
                    "&MID=" + MainActivity.flowbar + "&jsonStr=" +cnvJson, json)
            val jsonStr = JSONObject(jsonString)
            
        }
    }
}
