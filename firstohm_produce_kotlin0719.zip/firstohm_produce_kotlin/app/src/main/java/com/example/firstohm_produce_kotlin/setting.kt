package com.example.firstohm_produce_kotlin

import android.os.Bundle

import android.view.WindowManager
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.custom_layout_quant_input.*
import kotlinx.android.synthetic.main.activity_setting_layout.*

class setting: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_setting_layout)
        this.supportActionBar?.hide()  //hide title bar
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
        cancel.setOnClickListener {
            finish()
        }
        save.setOnClickListener {
            if(radioButton_33.isChecked==true)
            {
                MainActivity.ip="http://172.168.1.33/"
            }else{
                MainActivity.ip="http://172.168.1.151/"
            }
            MainActivity.dept=dept_spinner.getSelectedItem().toString()
            finish()
        }
        ArrayAdapter.createFromResource(
                this,
                R.array.dept,
                R.layout.obj_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(R.layout.obj_spinner_item)
            dept_spinner.adapter = adapter
        }
    }
}